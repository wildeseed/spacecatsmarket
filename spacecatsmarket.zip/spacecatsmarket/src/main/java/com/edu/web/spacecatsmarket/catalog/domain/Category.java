package com.edu.web.spacecatsmarket.catalog.domain;

import lombok.Value;

@Value
public class Category {

    CategoryId id;
    CategoryName name;
}
