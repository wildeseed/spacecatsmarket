package com.edu.web.spacecatsmarket.catalog.application.impl;

import com.edu.web.spacecatsmarket.catalog.application.ProductInventoryService;

public class ProductInventoryServiceImpl implements ProductInventoryService {
}
