package com.edu.web.spacecatsmarket.catalog.application;

public interface ProductInventoryService {
}
