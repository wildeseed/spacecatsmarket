package com.edu.web.spacecatsmarket.catalog.application.exceptions;

import lombok.experimental.StandardException;

@StandardException
public class CategoryNotFoundException extends RuntimeException {}
