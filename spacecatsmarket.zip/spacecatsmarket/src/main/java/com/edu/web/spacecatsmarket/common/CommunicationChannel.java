package com.edu.web.spacecatsmarket.common;

public enum CommunicationChannel {

    MOBILE,
    EMAIL,
    TELEPATHY,
    HOLOGRAM,
    PIGEON
}
