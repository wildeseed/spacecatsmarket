package com.edu.web.spacecatsmarket.catalog.application.impl;

import com.edu.web.spacecatsmarket.catalog.application.ProductPricingService;

public class ProductPricingServiceImpl implements ProductPricingService {
}
