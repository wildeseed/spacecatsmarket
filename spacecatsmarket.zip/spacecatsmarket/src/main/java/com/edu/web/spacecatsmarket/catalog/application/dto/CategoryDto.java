package com.edu.web.spacecatsmarket.catalog.application.dto;

public record CategoryDto(
        String id,
        String name
) {}
